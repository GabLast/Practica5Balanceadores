package edu.pucmm.practica2webadvanced;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica2WebAdvancedApplicationTests {

    @Test
    void contextLoads() {
    }

}
